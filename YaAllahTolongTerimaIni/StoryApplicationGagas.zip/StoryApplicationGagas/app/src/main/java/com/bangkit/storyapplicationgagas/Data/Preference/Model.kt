package com.bangkit.storyapplicationgagas.Data.Preference

data class Model(
    val username: String,
    val token: String ,
    val isLogin: Boolean = false
)